#include <iostream>
#include <conio.h>
#include <string>
#include <Windows.h>
#include "dungeonmap.h"

using namespace std;

int main(void) {
	char knapp;
	int posX = 2, posY = 1;
	dungeonmap main;
	main.drawMap();
	main.drawObjects();
	main.gotoxy(posX,posY);
	cout << 'P';
	while(main.onTrap(posX,posY) != true || main.onGoal(posX,posY) != true)
	{
		knapp = _getch();
		do
		{
		main.gotoxy(posX =+ 5,posY);
		main.onTrap(posX,posY);
		main.onGoal(posX,posY);
		cout << 'P';
		knapp = _getch();
		} while (knapp == 'd');
	}
	cin.get();
}