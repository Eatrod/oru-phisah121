#pragma once
#include <iostream>
#include <Windows.h>

using namespace std;

class dungeonmap
{
public:
	dungeonmap(void);
	void drawMap()
	{
		for (int i = 0; i < 26; ++i)
		{
			cout << "-";
		}
		cout << "\n";
		for (int i = 0; i < 6; ++i)
		{
			cout << "|    ";
		}
		cout << "\n";
		for (int i = 0; i < 26; ++i)
		{
			cout << "-";
		}
	}
	void drawObjects()
	{
		gotoxy(8,1);
		cout << 'T';
	}
	bool onTrap(int x,int y)
	{
		trapCheck = true;
		return trapCheck;
	}
	bool onGoal(int x, int y)
	{
		goalCheck = true;
		return goalCheck;
	}
	void gotoxy(int x, int y)
	{
		COORD coord;
		coord.X = x;
		coord.Y = y;
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
	}
	~dungeonmap(void);
private:
	bool trapCheck;
	bool goalCheck;
};

