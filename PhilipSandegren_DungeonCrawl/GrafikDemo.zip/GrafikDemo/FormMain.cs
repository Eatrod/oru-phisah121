﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GrafikDemo
{
    public partial class FormMain : Form
    {
        //Skapar alla variabler även om ¨många av dessa borde ligga i en klass
        public int posX { get; set; }
        public int posY { get; set; }
        public int pos2X { get; set; }
        public int pos2Y { get; set; }
        Pen blackPen = new Pen(Color.Black, 2);
        bool checkX = false;
        bool checkY = false;
        Random r = new Random();
        int Seed = (int)DateTime.Now.Ticks;
        Rectangle mainRect = new Rectangle();
        Rectangle secRect = new Rectangle();
        class myRectangle
        {
            Rectangle mainRect = new Rectangle();
            int speedX = 4;
            int speedY = 4;

        };


        public FormMain()
        {
            InitializeComponent();
            mainRect.X = posX; mainRect.Y = posY; mainRect.Width = 100; mainRect.Height = 100;
            secRect.X = pos2X; secRect.Y = pos2Y; secRect.Width = 100; secRect.Height = 100;
            //secRect(pos2X, pos2Y, 100, 100);
            this.Invalidate();
        }

        //Kontrollerar om de 2 rektanglarna överlappar
        public bool CollisionCheck()
        {
            bool collision = false;
            if (mainRect.IntersectsWith(secRect) == true)
                collision = true;
            return collision;
        }

        //Ritar ut båda rektanglarna
        private void FormMain_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawRectangle(blackPen, mainRect);
            g.DrawRectangle(blackPen, secRect);
        }

        //Flyttar en av rektanglarna till musens postion
        private void FormMain_MouseClick(object sender, MouseEventArgs e)
        {
            posX = e.X;
            posY = e.Y;
            mainRect.X = posX; mainRect.Y = posY; mainRect.Width = 100; mainRect.Height = 100;
            this.Invalidate();
        }

        //Läser av om användaren vill styra rektangeln
        private void FormMain_KeyDown(object sender, KeyEventArgs e)
        {
            if (posY >= 5)
            {
                if (e.KeyCode == Keys.Up)
                    posY -= 5;
            }
            if (posX >= 5)
            {
                if (e.KeyCode == Keys.Left)
                    posX -= 5;
            }
            if (posX <= 850)
            {
                if (e.KeyCode == Keys.Right)
                    posX += 5;
            }
            if (posY <= 620)
            {
                if (e.KeyCode == Keys.Down)
                    posY += 5;
            }
            label1.Text = ("posX: " + posX + "posY: " + posY);
            mainRect.X = posX; mainRect.Y = posY; mainRect.Width = 100; mainRect.Height = 100;
            this.Invalidate();
        }

        //Vid varje klocktick så kommer rektangeln att röra sig
        private void GameTick_Tick(object sender, EventArgs e)
        {
            //POS Y försöker bli större än fönstret uppåt
            if (posY <= 10)
            {
                checkY = true;
                if (CollisionCheck() == true)
                {
                    posY -= r.Next(4, 6);
                }
                else
                    posY += r.Next(4, 6);
            }
            if (checkY == true)
            {               
                if (CollisionCheck() == true)
                {
                    posY -= r.Next(4, 6);

                }
                else
                    posY += r.Next(4, 6);
            }
            
            //POS X försöker bli mindre än fönstret vänster
            if (posX <= 10)
            {
                checkX = true;
                if (CollisionCheck() == true)
                {
                    posX -= r.Next(4, 6);
                }
                else
                    posX += r.Next(4, 6);
            }
            if (checkX == true)
            {
                if (CollisionCheck() == true)
                {
                    posX += r.Next(4, 6);

                }
                else
                    posX += r.Next(4, 6);
            }
            
            //POS X försöker bli större än fönstret höger
            if (posX >= 750)
            {
                checkX = false;
                if (CollisionCheck() == true)
                {
                    posX += r.Next(4, 6);
                }
                else
                    posX -= r.Next(4, 6);
            }
            if (checkX == false)
            {
                if (CollisionCheck() == true)
                {
                    posX += r.Next(4, 6);
                }
                else
                    posX -= r.Next(4, 6);
            }
            
            //POS Y försöker bli större än fönstret neråt
            if (posY >= 520)
            {
                checkY = false;
                if (CollisionCheck() == true)
                {
                    posY += r.Next(4, 6);
                }
                else
                    posY -= r.Next(4, 6);
            }
            if (checkY == false)
            {
                if (CollisionCheck() == true)
                {
                    posY += r.Next(4, 6);
                }
                else
                    posY -= r.Next(4, 6);
            }

            label1.Text = ("posX: " + posX + "posY: " + posY);
            mainRect.X = posX; mainRect.Y = posY; mainRect.Width = 100; mainRect.Height = 100;
            secRect.X = pos2X; secRect.Y = pos2Y; secRect.Width = 100; secRect.Height = 100;
            this.Invalidate();
        }
    }
}
